from sqlalchemy import create_engine, text
from sqlalchemy.types import Numeric, NVARCHAR
import urllib
import re
import pandas as pd
import Scripts.prod.conn as conn
from IPython.display import display
conect = conn.SQLServer()

file_path = "fema_2604.xlsx"
engine = conect.connector_engine_BA

match = re.search(r'(\d{4})', file_path)

if match:
    ym = match.group(1)

    year = 2000 + int(ym[:2])
    month = int(ym[2:])

    print(year, month)

with engine.connect() as conn:
    result = conn.execute(text("SELECT TOP (5) * FROM Business_Analytic.prod.temp"))

    for row in result:
        print(row)


pd.set_option('display.max_rows', None)
pd.set_option('display.max_columns', None)


column_names = ["Дата",	"Час",	"Магазин",	"Витяжка ПКВ",	"Гриль шаурма",	"Ел. плита",
"Модульна піч",	"ПКВ",	"ПКВ гриль",	"ПКВ допік",	"ПКВ копчення",	"ПКВ піч",	"Піч Піца1",
"Піч піца",	"Піч піца1",	"Піч піца2",	"Розстоєчна шафа",	"Ротаційна піч",	"Тензометрія ПКВ",
"Тензометрія ПКВ гриль",	"Тензометрія ПКВ допік",	"Тензометрія ПКВ копчення",	"Тензометрія Теплова вітрина",
"Тензометрія Теплова вітрина1",	"Тензометрія Теплова вітрина2",	"Теплова вітрина",	"Теплова вітрина 1",
"Теплова вітрина1",	"Теплова вітрина2",	"ЩС Піца",	"ЩС пекарня",	"ЩС піца"
]
column_names = [''.join(x.lower().split()) for x in column_names]
print(column_names)
df = pd.read_excel(
    file_path,
    sheet_name=0
)
df.columns = [''.join(x.lower().split()) for x in df.columns]
print(df.columns)
# df = df.groupby(
#     ["year", "month", "ym", "rcid", "filid", "lagerid", "proekt"],
#     as_index=False
# )[["costs"]].sum()
#
missing_columns = [col for col in column_names if col not in df.columns]

print("Відсутні колонки:")
print(missing_columns)

# залишаємо тільки потрібні колонки
df = df[[col for col in column_names if col in df.columns]]

# групуємо дублікати колонок і сумуємо їх
df = df.T.groupby(level=0).sum().T
print(df.head())

df_final = pd.DataFrame(columns=[
    "Filid",
    "year",
    "month",
    "Пиццерия",
    "Гриль",
    "Стріт-Фуд",
    "Допёк",
    "Пекарня"
])


with engine.connect() as conn:
    query = "SELECT  [id],[name],[AccountantNumber] FROM [FORAExperts].[dbo].[Filialparams]"

    df_filials = pd.read_sql(query, engine)

print(df_filials.head())

df_filials["AccountantNumber"] = (
    pd.to_numeric(
        df_filials["AccountantNumber"],
        errors="coerce"
    )
    .astype("Int64")
)
# беремо код магазину до першої коми та прибираємо пробіли
df["AccountantNumber"] = (
    pd.to_numeric(
        df["магазин"]
        .str.split(",").str[0]
        .str.replace(" ", "", regex=False),
        errors="coerce"
    )
    .astype("Int64")
)

# join з довідником філіалів
df = df.merge(
    df_filials[["AccountantNumber", "id"]],
    on="AccountantNumber",
    how="left"
)

df_final["Filid"]=df["id"]
df_final["year"]=year
df_final["month"]=month

cols_pizza = ['пквпіч', 'пічпіца1', 'пічпіца', 'пічпіца1', 'пічпіца2', 'тепловавітрина1', 'тепловавітрина1', 'щспіца', 'щспіца']
existing_cols_pizza = [col for col in cols_pizza if col in df.columns]
df["Пиццерия"] = df[existing_cols_pizza].sum(axis=1)
print(df["Пиццерия"].sum())
print(df.head(15))
# delete old data
# 1. перевірити чи таблиця є
# with engine.connect() as conn:
#     exists = conn.execute(text("""
#         SELECT OBJECT_ID('prod.costsmc', 'U')
#     """)).scalar()
#
# # 2. тільки якщо є — delete
# if exists:
#     with engine.begin() as conn:
#         conn.execute(text("""
#             DELETE FROM prod.costsmc
#             WHERE [year] = :year
#               AND [month] = :month
#         """), {"year": year, "month": month})

# df.to_sql(
#     "costsmc_python_test",
#     engine,
#     schema="prod",
#     if_exists="append",
#     index=False,
#     dtype={
#         "costs": Numeric(12, 2),
#         "proekt": NVARCHAR(8)
#     }
# )